<?php
require_once 'Conexion.php';

class Libro {
  public static function obtenerTodos() {
    $db = Conexion::conectar();
    $stmt = $db->query("SELECT libros.*, categorias.nombre AS categoria FROM libros JOIN categorias ON libros.categoria_id = categorias.id");
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
  }

  public static function obtenerPorCategoria($categoria) {
    $db = Conexion::conectar();
    $stmt = $db->prepare("SELECT libros.*, categorias.nombre AS categoria FROM libros JOIN categorias ON libros.categoria_id = categorias.id WHERE categorias.nombre = :categoria");
    $stmt->bindParam(':categoria', $categoria, PDO::PARAM_STR);
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
  }
}

?>
