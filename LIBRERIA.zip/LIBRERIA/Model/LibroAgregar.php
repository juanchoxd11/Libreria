<?php
require_once 'Conexion.php';

class LibroAgregar {
    public static function agregarLibro($titulo, $categoria_id, $precio, $descripcion, $imagen, $cantidad) {
        $conexion = Conexion::conectar();
        $sql = "INSERT INTO libros (titulo, categoria_id, precio, descripcion, imagen, cantidad)
                VALUES (?, ?, ?, ?, ?, ?)";

        $stmt = $conexion->prepare($sql);
        return $stmt->execute([$titulo, $categoria_id, $precio, $descripcion, $imagen, $cantidad]);
    }
}
