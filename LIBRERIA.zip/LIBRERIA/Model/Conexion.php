<?php
// Definimos una clase llamada 'Conexion' para manejar la conexión a la base de datos
class Conexion {
  // Método estático que establece y retorna la conexión a la base de datos
  public static function conectar() {
    // Parámetros de conexión: servidor, nombre de la base de datos, usuario y contraseña
    $host = 'localhost';      // Servidor de la base de datos
    $dbname = 'libreria';     // Nombre de la base de datos
    $user = 'root';           // Usuario de la base de datos
    $pass = '';               // Contraseña del usuario

    try {
      // Crear una nueva instancia de PDO para conectarse a la base de datos
      $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $user, $pass);
      // Configurar el modo de error de PDO para que lance excepciones
      $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
      // Retornar la instancia de PDO
      return $pdo;
    } catch (PDOException $e) {
      // En caso de error, mostrar el mensaje y terminar la ejecución
      die("Error en la conexión: " . $e->getMessage());
    }
  }
}
?>
